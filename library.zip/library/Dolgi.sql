CREATE TABLE IF NOT EXISTS public."Dolgi"
(
    uid uuid NOT NULL,
    book_uuid uuid NOT NULL,
    "Reader_uuid" uuid NOT NULL,
    CONSTRAINT "Dolgi_pkey" PRIMARY KEY (uid, book_uuid, "Reader_uuid")
)