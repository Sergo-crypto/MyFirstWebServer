CREATE TABLE IF NOT EXISTS public."Published"
(
    uid uuid NOT NULL,
    name text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Published_pkey" PRIMARY KEY (uid)
)