CREATE TABLE IF NOT EXISTS public."Author"
(
    uid uuid NOT NULL,
    name text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Author_pkey" PRIMARY KEY (uid)
)