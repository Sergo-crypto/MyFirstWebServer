export const EItemStatus = {
    Destroy: 'Сломан',
    Ok: 'Ок',
    Repair: 'В ремонте'
}