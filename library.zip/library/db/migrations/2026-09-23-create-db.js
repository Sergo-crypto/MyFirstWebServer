import Migration from "../migration.js";

async function createDB() {
	const migration = new Migration();
	await migration.up(`PRAGMA foreign_keys = ON;`);

	// 1. structure (Здание) - не зависит от других
	await migration.up(`
		CREATE TABLE IF NOT EXISTS structure (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			address TEXT NOT NULL
		);
	`);

	// 2. floor (Этаж) - зависит от structure
	await migration.up(`
		CREATE TABLE IF NOT EXISTS floor (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			structure_id INTEGER NOT NULL,
			FOREIGN KEY (structure_id) REFERENCES structure(id) ON DELETE CASCADE
		);
	`);

	// 3. room (Комната) - зависит от floor
	await migration.up(`
		CREATE TABLE IF NOT EXISTS room (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			floor_id INTEGER NOT NULL,
			FOREIGN KEY (floor_id) REFERENCES floor(id) ON DELETE CASCADE
		);
	`);

	// 4. place (Место/Стол) - зависит от room
	await migration.up(`
		CREATE TABLE IF NOT EXISTS place (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			room_id INTEGER NOT NULL,
			FOREIGN KEY (room_id) REFERENCES room(id) ON DELETE CASCADE
		);
	`);

	// 5. location (Локация/Точка) - зависит от place
	await migration.up(`
		CREATE TABLE IF NOT EXISTS location (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			place_id INTEGER NOT NULL,
			FOREIGN KEY (place_id) REFERENCES place(id) ON DELETE CASCADE
		);
	`);

	// 6. category (Категория) - независимая (ссылается сама на себя)
	await migration.up(`
		CREATE TABLE IF NOT EXISTS category (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			parent_id INTEGER,
			FOREIGN KEY (parent_id) REFERENCES category(id) ON DELETE SET NULL
		);
	`);

	// 7. item (Предмет) - зависит от category и location (создается ПОСЛЕДНИМ)
	await migration.up(`
		CREATE TABLE IF NOT EXISTS item (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL,
			properties TEXT NOT NULL,
			status TEXT NOT NULL,
			category_id INTEGER,
			location_id INTEGER,
			current_location_id INTEGER,
			FOREIGN KEY (category_id) REFERENCES category(id) ON DELETE SET NULL,
			FOREIGN KEY (location_id) REFERENCES location(id) ON DELETE SET NULL,
			FOREIGN KEY (current_location_id) REFERENCES location(id) ON DELETE SET NULL
		);
	`);
    
    console.log("База данных успешно создана!");
}

(async () => {
    try {
        await createDB();
    } catch (error) {
        console.error("Ошибка при создании БД:", error);
    }
})();