import ItemService from "./item.service";
import {isNotEmptyArray} from "../utils.js"
export const delteItem = async (ctx) => {

};

service = new ItemService()

export const getItem = async (ctx) => {
    const{id} = ctx.params;
    const res = await service.getItem(id);
    ctx.status = 200
    ctx.body = {
        data: res,
    };
};

export const getItems = async (ctx) => {
    const service = new ItemService();
    const {id} = ctx.params;
    const items = service.getAll({
        ids: isNotEmptyArray(id) ? (id) : [id],
        name: isString(name) ? name : undefined,
        locations:  isNotEmptyArray(location) ? (location) : [location],
    });
    
};

export const updateItem = async (ctx) => {
    const { id } = ctx.params;
     const data = ctx.request.body;

     const res = await this.service.update(id, data);

    ctx.status = 200;
    ctx.body = {
        data:res,
    };
}

export const createItem = async (ctx) => {
    const data = ctx.request.body;
    const res = await this.service.create(data);

    ctx.status = 200;
    ctx.body = {
        data:res,
    };
}

export const deleteItem = async (ctx) => {
    const { id } = ctx.params;

    await this.service.softDelete(id)

    ctx.status = 200;
    ctx.body = {
        status: 200,
        messege: 'OK',
    };
}

// такие контроллеры называют end-point они вызываются по определению url