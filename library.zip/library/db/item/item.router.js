import Router from '@koa/router'
import ItemController from './item/item.controller.js'
const router = new Router({
    prefix: '/items',
});
const controller = new ItemController();
router.get('/', controller.getItem.bind(controller));
router.get('/:id', controller.getItem.bind(controller));
router.patch('/:id', controller.updateItem.bind(controller));
router.delete('/:id', controller.deleteItem.bind(controller));
router.post('/', controller.createItem.bind(controller));


koa.listen(3000);