const users = [
    {
        id: 12,
        name: 'Max',
    }
];


export const getItem = async (ctx) => {
    ctx.status = 200;
    ctx.body = user[0];
}; 

export const deleteItem = async (ctx) => {
    const id = ctx.params.id;
    const deletedItem = user.find((u) => u.id === id);

    // if (itemIndex === -1)
    if (!~itemIndex)
    {
        ctx.status = 403;
        ctx.body = 'item is not deleted';
    }

    users[itemIndex] = null;
    // user.splice(deletedItem,1)[0];

    ctx.status = 200;
    ctx.body = 'success';
};

export const createItem = async (ctx) => {
    const item = ctx.request.body;
    users.push(item);
    ctx.status = 200;
    ctx.body = 'Item added!';
};

export const updateItem = async ctx => {
    const id = ctx.request.body?.id;
    const name = ctx.request.body?.name;

    if (name !== null)
    {
        const user = user.find(u => u.id === id);
        user.name = name;
    }

    ctx.status = 200;
    ctx.body = user;
}








// export const createItem = async (ctx) => {
//     ctx.status = 201;
//     ctx.body = {};
// };

// export const updateItem = async (ctx) => {
//     ctx.status = 200;
//     ctx.body = {};
// };

// export const deleteItem = async (ctx) => {
//     ctx.status = 204;
//     ctx.body = null;
// };








// const deleteItem = async (ctx) => {};
// const updateItem = async (ctx) => {};
// const createItem = async (ctx) => {};