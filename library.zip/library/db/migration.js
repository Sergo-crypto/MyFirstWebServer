import Sqlitelinker from "./sqlite.js"; 

export default class Migration {

    constructor() {
        this.linker = new Sqlitelinker('./database.db');
    }

    async #exec(sql) {
        if (typeof sql !== 'string' || sql.trim() === '' ) {
            throw new Error("Запрос непустой строкой");
        }
        try{
            await this.linker.connect();
            await this.linker.run(sql);
        }
        catch(error) {
            console.error(`Ошибка \n${error}`);
        }
        finally {
        }
    }

    async up(sql) {
        console.log("up");
        
        await this.#exec(sql);
    }

    async down(sql) {
        console.log("down");

        await this.#exec(sql);
    }
}
