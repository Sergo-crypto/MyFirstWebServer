import {isString, isNotEmpty, isNumber} from '../../utils.js';

export default class PlaceDTO {
    constructor({name, place_id}){
        this.name = name;
        this.place_id = place_id
    }

    #checkObject(){
        return(
            isString(this.name) &&
            isString(this.place_id)&&
            isNotEmpty(this.name) &&
            isNotEmpty(this.place_id)
        );
    }

    get object(){
        if (!this.checkObject())
            throw new Error ('Try another data for this object!');

        return {
            name: this.name,
            place_id: this.place_id,
        };
    }
}