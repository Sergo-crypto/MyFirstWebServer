import {isString, isNotEmpty, isNumber} from '../../utils.js';

export default class RoomDto {
    constructor({name, room_id}){
        this.name = name;
        this.room_id = room_id
    }

    #checkObject(){
        return(
            isString(this.name) &&
            isString(this.room_id)&&
            isNotEmpty(this.name) &&
            isNotEmpty(this.room_id)
        );
    }

    get object(){
        if (!this.checkObject())
            throw new Error ('Try another data for this object!');

        return {
            name: this.name,
            room_id: this.room_id,
        };
    }
}