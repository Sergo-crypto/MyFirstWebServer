// import sqlite from 'sqlite3';

// export default class SqliteLinker
// {
//     constructor(filename)
//     {
//         this.filename = filename;
//         this.db = null;
//     }
//     /**
//      *Отвечает за создание и открытие подключения к файлу базы данных SQLite.
//      */
//     async connect() {
//     return new Promise((resolve, reject) => {
//         this.db = new sqlite.Database(this.filename, (err) => {
//             if (err) {
//                 console.log(JSON.stringify(err));
//                 reject(err);
//                 return;
//             }
//             console.log(`Database is started... on the ${this.filename}`);  // ← Обратные кавычки!
//             resolve(this.db);
//         });
//     });
// }

//     /**
//      * Этот код отвечает за выполнение SQL-запросов, изменяющих данные (INSERT, UPDATE, DELETE),
//      *  и возвращает ID последней вставленной строки (lastID) и количество измененных строк (changes).
//      */
//     async run(sql, params = []) {
//     const result = await new Promise((resolve, reject) => {  // ← Стрелочная функция!
//         this.db.run(sql, params, function(err) {
//             if (err) {
//                 console.log(err);
//                 reject(err);
//                 return;
//             }
//             resolve({
//                 lastId: this.lastID,
//                 changes: this.changes,
//             });
//         });
//     });
//     return result;
// }

//     /**
//      * Отвечает за выполнение SQL-запроса (SELECT)
//      * и возврат только одной первой найденной строки (в виде объекта).
//      */
//     async get(sql, params = []){
//         const result = await new Promise(function (resolve,reject){
//             this.db.get(sql,params,function(err, row){
//                 if(err){
//                     console.log(err);
//                     reject(err);
//                     return;
//                 }
//                 resolve(row);
//             });
//         });
//         return result;
//     }
    
//     /**
//      отвечает за выполнение SQL-запроса и возврат всех найденных строк (в виде массива объектов).
//      */
//     async all(sql, params = []){
//         const result = await new Promise(function (resolve,reject){
//             this.db.get(sql,params,function(err, rows){
//                 if(err){
//                     console.log(err);
//                     reject(err);
//                     return;
//                 }
//                 resolve(rows);
//             });
//         });
//         return result;
//     }

//     /**
//      Оборачивает процесс закрытия БД в Promise.
//     Вызывает метод this.db.close().
//     При ошибке выводит её и отклоняет промис (reject).
//     При успехе должен завершать промис.
//      */
//     async close(){
//         return new Promise(function(resolve, reject){
//             this.db.close(function(err){
//                 if (err){
//                     console.log(err);
//                     reject(err);
//                     return;
//                 }
//                 resolve;
//             });
//         });
//     }

// }


import sqlite from 'sqlite3';

class Database {
    constructor(filename) {
        this.filename = filename;
        this.db = null;
    }

    async connect() {
    return new Promise((resolve, reject) => {
        this.db = new sqlite.Database(this.filename, (err) => {
            if (err) {
                console.log(JSON.stringify(err));
                reject(err);
                return;
            }
            console.log(`Database is started... on the ${this.filename}`); // ← Обратные кавычки!
            resolve(this.db);
        });
    });
}

    async run(sql, params = []) {
        const result = await new Promise((resolve, reject) => {  // ← ИСПРАВЛЕНО
            this.db.run(sql, params, function(err) {
                if (err) {
                    console.log(err);
                    reject(err);
                    return;
                }
                resolve({
                    lastId: this.lastID,
                    changes: this.changes,
                });
            });
        });
        return result;
    }

    async get(sql, params = []) {
        const result = await new Promise((resolve, reject) => {  // ← ИСПРАВЛЕНО
            this.db.get(sql, params, function(err, row) {
                if (err) {
                    console.log(err);
                    reject(err);
                    return;
                }
                resolve(row);
            });
        });
        return result;
    }

    async all(sql, params = []) {
        const result = await new Promise((resolve, reject) => {  // ← ИСПРАВЛЕНО
            this.db.all(sql, params, function(err, rows) {
                if (err) {
                    console.log(err);
                    reject(err);
                    return;
                }
                resolve(rows);
            });
        });
        return result;
    }

    async close() {
        return new Promise((resolve, reject) => {  // ← ИСПРАВЛЕНО
            this.db.close(function(err) {
                if (err) {
                    console.log(err);
                    reject(err);
                    return;
                }
                resolve();
            });
        });
    }

    createPlaceholder(arr) {
        return arr.map(() => '?').join(',');
    }

    createSetBlock(properties){
        const values = [];
        const block = Object.entries(properties)
        .map(([key, value]) => {
            if (isEmpty(value)) return null;

            values.push(value);
            return ` ${key} = ?`;
        })
        .filter((p) => p !== null)
        .join(',');

        return{block,values};
    }
}

export default Database;