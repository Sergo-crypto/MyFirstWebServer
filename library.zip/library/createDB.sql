CREATE TABLE IF NOT EXISTS public."Book"
(
    uid uuid NOT NULL,
    isbn text COLLATE pg_catalog."default" NOT NULL,
    name text COLLATE pg_catalog."default" NOT NULL,
    date timestamp with time zone NOT NULL,
    author_uid uuid NOT NULL,
    published_uid uuid NOT NULL,
    CONSTRAINT "Book_pkey" PRIMARY KEY (uid)
);
END;