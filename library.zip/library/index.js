import Koa from 'koa';
import bodyParser from 'koa-bodyparser';
import {ItemController} from './item/item.router.js';

const koa = new Koa();

// const router = new Router();

// koa.use(bodyparser());
// router.get('/', getItem);

// koa.use(router.routes());
// koa.use(router.allowedMethods());



app.use(itemRouter.routes());
app.user(itemRouter.allowedMethods());

koa.listen(3000);






// koa.use((ctx) => {
//   ctx.body = 'Hello world';
// })