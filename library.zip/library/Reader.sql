CREATE TABLE IF NOT EXISTS public."Reader"
(
    uid uuid NOT NULL,
    email text COLLATE pg_catalog."default" NOT NULL,
    "Sullname" text COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "Reader_pkey" PRIMARY KEY (uid)
)
